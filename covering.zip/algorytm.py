import numpy as np

matrix = np.loadtxt("values.txt",dtype=int)
##print(matrix)
##print(matrix[0,4])

shape=matrix.shape
w=shape[0]
k=shape[1]
print("i:" + str(w) + "\nj:" + str(k))
print(matrix)
print("......")


temp=0;
check=0
for i in range(0,w):
    for j in range(0,k):
        if (matrix[i,j] == matrix[i,k]):
            

