def generate_combinations(n, k):
    result = []

    def backtrack(start, current):
        if len(current) == k:
            result.append(tuple(current))
            return

        for i in range(start, n):
            current.append(i)
            backtrack(i + 1, current)
            current.pop()

    backtrack(0, [])
    return result


def covering_algorithm(decision_system):
    objects = decision_system.copy()
    num_attributes = len(objects[0]) - 1
    decision_index = num_attributes
    rules = []
    uncovered = list(range(len(objects)))

    rule_order = 1
    while uncovered and rule_order <= num_attributes:
        uncovered_before = uncovered.copy()
        i = 0
        while i < len(uncovered):
            object_index = uncovered[i]
            obj = objects[object_index]
            decision = obj[decision_index]
            combinations = generate_combinations(num_attributes, rule_order)
            rule_found = False
            for comb in combinations:
                conditions = [(attr, obj[attr]) for attr in comb]
                is_consistent = True
                for other_obj in objects:
                    if all(other_obj[attr] == value for attr, value in conditions) and other_obj[
                        decision_index] != decision:
                        is_consistent = False
                        break

                if is_consistent:
                    rules.append((conditions, decision))
                    j = 0
                    while j < len(uncovered):
                        idx = uncovered[j]
                        covered_obj = objects[idx]
                        if all(covered_obj[attr] == value for attr, value in conditions) and covered_obj[
                            decision_index] == decision:
                            uncovered.pop(j)
                        else:
                            j += 1
                    rule_found = True
                    break
            if not rule_found:
                i += 1
        if uncovered == uncovered_before:
            rule_order += 1
    return rules




import numpy as np

matrix = np.loadtxt("test.txt",dtype=str, delimiter=',')
rules = covering_algorithm(matrix)


print("Reguly:")
for i, (conditions, decision) in enumerate(rules):
    conditions_str = " AND ".join([f"a{attr + 1}={value}" for attr, value in conditions])
    print(f"Rule {i + 1}: IF {conditions_str} THEN d={decision}")


covered_objects = set()
for i, obj in enumerate(matrix):
    for conditions, decision in rules:
        if all(obj[attr] == value for attr, value in conditions) and obj[-1] == decision:
            covered_objects.add(i)
            break
