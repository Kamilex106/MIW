def generate_combinations(arr, k):
    """Generator kombinacji k-elementowych bez itertools"""
    if k == 0 or k > len(arr):
        return
    indices = list(range(k))

    while True:
        yield [arr[i] for i in indices]
        i = k - 1
        while i >= 0 and indices[i] == len(arr) - k + i:
            i -= 1
        if i < 0:
            return
        indices[i] += 1
        for j in range(i + 1, k):
            indices[j] = indices[j - 1] + 1


def sequential_covering(objects):
    rules = []
    active_objects = objects.copy()
    max_length = len(objects[0]) - 1 if objects else 0

    for rule_length in range(1, max_length + 1):
        while True:
            rule_added = False
            for i, obj in enumerate(active_objects):
                attributes = [attr for attr in obj if attr != 'd']

                for combo in generate_combinations(attributes, rule_length):
                    candidate = {attr: obj[attr] for attr in combo}
                    decision = None
                    covered = []
                    consistent = True

                    for o in objects:
                        if all(o[attr] == val for attr, val in candidate.items()):
                            if decision is None:
                                decision = o['d']
                            elif o['d'] != decision:
                                consistent = False
                                break
                            covered.append(o)

                    if consistent and decision is not None:
                        relevant = [o for o in covered if o in active_objects]
                        if relevant:
                            rules.append((candidate, decision))
                            active_objects = [o for o in active_objects if o not in covered]
                            rule_added = True
                            break
                    if rule_added:
                        break
                if rule_added:
                    break
            if not rule_added:
                break

    return rules


import numpy as np

matrix = np.loadtxt("values2.txt",dtype=str, delimiter=':')
rules = sequential_covering(matrix)

result = sequential_covering(example_data)

for i, (rule, dec) in enumerate(result, 1):
    cond = " ∧ ".join([f"({k} = {v})" for k, v in rule.items()])
    print(f"Reguła {i}: {cond} ⇒ (d = {dec})")